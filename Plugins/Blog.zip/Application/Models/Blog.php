<?php

class Blog extends AppModel
{

}

?>